var app = angular.module("ControllerApp",[]);
// parent controller
app.controller("parentctrl",function ($scope) {
    $scope.text = "";
});
// child controller
app.controller("childctrl",function ($scope) {
   // $scope.text = "";
});