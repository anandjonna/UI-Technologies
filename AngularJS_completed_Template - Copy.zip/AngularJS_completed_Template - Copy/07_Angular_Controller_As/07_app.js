var app = angular.module("controllerAsApp",[]);
app.controller("Parentctrl",function () {
    this.text = "";
});
app.controller("childctrl",function () {
    this.text = "";
});