var app = angular.module("CalculatorApp",[]);
app.controller("CalcAppctrl",function($scope){
    this.operator = '+';
    this.result = "reslut";
    this.changeOperator = function(opr){
        this.operator = opr;

    };
    this.findResults = function(){
        switch (this.operator) {
            case '+':
               this.result = this.num1 + this.num2;
                break;
            case '-':
                this.result = this.num1 - this.num2;
                break;
            case '/':
                this.result = this.num1 / this.num2;
                break;
            case '*':
                this.result = this.num1 * this.num2;
                break;
            default:
                this.result = "result";
                break;
        }



    };
    this.clear = function () {
        this.num1 = "";
        this.num2 = "";
        this.result = "result";
        this.operator = "+";

    }

});
