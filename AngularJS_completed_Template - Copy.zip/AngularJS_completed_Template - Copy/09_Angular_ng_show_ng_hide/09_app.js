angular.module("HobbiesApp",[]).controller("HobbiesAppctrl",function () {
  this.eating =false;
  this.sleeping = false;
  this.coding = false;
});