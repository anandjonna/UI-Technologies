angular.module("GoodmorningApp",[]).controller("Goodmorningctrl",function () {
    this.times = "";
    this.myArray = [];
    this.getTimes = function () {
        if(this.times!== null){
            for(var i=0;i<this.times;i++){
                this.myArray[i]=i+1;
            }

        }
        else{
            this.myArray = [];
        }

    }

});